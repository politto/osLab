#include <stdio.h>

int main()
{
	printf("%d\n", 20);
	return (0);
}
