#include <stdio.h>

int	main()
{
	printf("%d\n", 20;
}
