salutation = "Hello"
echo $salutation
echo "The program $0 is now running"
echo "The first param is $1"
echo "The second param is $2"
echo "the param list is $*"
echo "the user's home folder is $HO<E"
exit 0
